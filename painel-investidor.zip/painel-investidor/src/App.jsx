import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Legend,
} from "recharts";
import { Plus, Trash2, TrendingUp, Wallet, Calculator, X } from "lucide-react";

// ---------- helpers ----------
const CATEGORY_STYLES = {
  "Ações": { color: "#C9A227", glyph: "AÇ" },
  "Renda Fixa": { color: "#5B8AA6", glyph: "RF" },
  "Fundos Imobiliários": { color: "#3FA796", glyph: "FI" },
  "Cripto": { color: "#E4572E", glyph: "CR" },
  "Internacional": { color: "#8B6FB3", glyph: "IN" },
};
const FALLBACK_PALETTE = ["#C9A227", "#5B8AA6", "#3FA796", "#E4572E", "#8B6FB3", "#B5C99A", "#D98EA3"];
const STORAGE_KEY = "painel-investidor:holdings";

function styleFor(category, indexHint = 0) {
  if (CATEGORY_STYLES[category]) return CATEGORY_STYLES[category];
  const color = FALLBACK_PALETTE[Math.abs(hashCode(category) + indexHint) % FALLBACK_PALETTE.length];
  return { color, glyph: category.slice(0, 2).toUpperCase() };
}
function hashCode(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h << 5) - h + str.charCodeAt(i);
  return h;
}
const brl = (n) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(n || 0);
const brlFull = (n) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 2 }).format(n || 0);

const SEED = [
  { id: "s1", category: "Ações", name: "Carteira de ações BR", value: 18500 },
  { id: "s2", category: "Renda Fixa", name: "Tesouro Selic", value: 24000 },
  { id: "s3", category: "Fundos Imobiliários", name: "FIIs diversos", value: 9200 },
  { id: "s4", category: "Cripto", name: "BTC / ETH", value: 4100 },
];

export default function App() {
  const [holdings, setHoldings] = useState(null); // null = loading
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ category: "Ações", name: "", value: "" });
  const [customCategory, setCustomCategory] = useState(false);

  // simulator state
  const [simInicial, setSimInicial] = useState(55000);
  const [simAporte, setSimAporte] = useState(1000);
  const [simAnos, setSimAnos] = useState(15);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      setHoldings(raw ? JSON.parse(raw) : SEED);
    } catch {
      setHoldings(SEED);
    }
  }, []);

  const persist = useCallback((next) => {
    setHoldings(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* best effort */
    }
  }, []);

  const addHolding = () => {
    const val = parseFloat(form.value.toString().replace(",", "."));
    if (!form.category.trim() || !form.name.trim() || !val || val <= 0) return;
    const next = [
      ...holdings,
      { id: `h${Date.now()}`, category: form.category.trim(), name: form.name.trim(), value: val },
    ];
    persist(next);
    setForm({ category: form.category, name: "", value: "" });
    setShowAdd(false);
  };

  const removeHolding = (id) => persist(holdings.filter((h) => h.id !== id));

  const total = useMemo(() => (holdings || []).reduce((s, h) => s + h.value, 0), [holdings]);

  const byCategory = useMemo(() => {
    const map = new Map();
    (holdings || []).forEach((h) => {
      map.set(h.category, (map.get(h.category) || 0) + h.value);
    });
    return Array.from(map.entries()).map(([category, value], i) => ({
      category,
      value,
      pct: total ? (value / total) * 100 : 0,
      ...styleFor(category, i),
    }));
  }, [holdings, total]);

  // ---- simulator math ----
  const scenarios = [
    { label: "Conservador", rate: 0.09, color: "#5B8AA6" },
    { label: "Moderado", rate: 0.12, color: "#C9A227" },
    { label: "Arrojado", rate: 0.16, color: "#E4572E" },
  ];
  const simData = useMemo(() => {
    const months = Math.max(1, Math.round(simAnos * 12));
    const rows = [];
    for (let m = 0; m <= months; m += Math.max(1, Math.round(months / 30))) {
      const row = { mes: m, ano: (m / 12).toFixed(1) };
      scenarios.forEach((sc) => {
        const rm = Math.pow(1 + sc.rate, 1 / 12) - 1;
        const fv = simInicial * Math.pow(1 + rm, m) + simAporte * ((Math.pow(1 + rm, m) - 1) / (rm || 1));
        row[sc.label] = Math.round(fv);
      });
      rows.push(row);
    }
    return rows;
  }, [simInicial, simAporte, simAnos]);

  if (holdings === null) {
    return (
      <div style={{ background: BG, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <span style={{ color: TEXT_MUTED, fontFamily: MONO }}>carregando carteira…</span>
      </div>
    );
  }

  return (
    <div style={{ background: BG, minHeight: "100vh", color: TEXT, fontFamily: BODY }}>
      <style>{FONT_IMPORTS}</style>

      {/* Ticker tape */}
      <div style={{ borderBottom: `1px solid ${BORDER}`, background: PANEL, overflow: "hidden", padding: "10px 0" }}>
        <div style={{ display: "flex", gap: 40, whiteSpace: "nowrap", animation: "ticker 28s linear infinite", width: "max-content" }}>
          {[...holdings, ...holdings].map((h, i) => {
            const st = styleFor(h.category);
            return (
              <span key={i} style={{ fontFamily: MONO, fontSize: 13, letterSpacing: 0.5, color: TEXT_MUTED }}>
                <b style={{ color: st.color }}>{st.glyph}</b> {h.name.toUpperCase()}{" "}
                <span style={{ color: TEXT }}>{brl(h.value)}</span>
              </span>
            );
          })}
        </div>
      </div>

      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "28px 20px 60px" }}>
        {/* Header */}
        <header style={{ marginBottom: 28 }}>
          <div style={{ fontFamily: MONO, fontSize: 12, color: GOLD, letterSpacing: 2, marginBottom: 6 }}>
            PAINEL · CARTEIRA PESSOAL
          </div>
          <h1 style={{ fontFamily: DISPLAY, fontSize: "clamp(28px,5vw,44px)", fontWeight: 600, margin: 0, lineHeight: 1.05 }}>
            Sua bolsa, num só lugar
          </h1>
          <p style={{ color: TEXT_MUTED, marginTop: 8, maxWidth: 560 }}>
            Acompanhe onde seu dinheiro está hoje e simule para onde ele pode ir.
          </p>
        </header>

        {/* Total + allocation */}
        <section style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 20, marginBottom: 20 }} className="grid-stack">
          <div style={cardStyle}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: TEXT_MUTED, fontSize: 13 }}>
              <Wallet size={15} /> PATRIMÔNIO TOTAL
            </div>
            <div style={{ fontFamily: DISPLAY, fontSize: 40, fontWeight: 600, marginTop: 6 }}>{brlFull(total)}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 20 }}>
              {byCategory.map((c) => (
                <div key={c.category}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                    <span style={{ color: TEXT }}>{c.category}</span>
                    <span style={{ fontFamily: MONO, color: TEXT_MUTED }}>{brl(c.value)} · {c.pct.toFixed(0)}%</span>
                  </div>
                  <div style={{ height: 6, borderRadius: 3, background: PANEL_ALT, overflow: "hidden" }}>
                    <div style={{ width: `${c.pct}%`, height: "100%", background: c.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ ...cardStyle, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="category" innerRadius={62} outerRadius={92} paddingAngle={2}>
                  {byCategory.map((c, i) => <Cell key={i} fill={c.color} stroke={BG} strokeWidth={2} />)}
                </Pie>
                <Tooltip
                  contentStyle={{ background: PANEL_ALT, border: `1px solid ${BORDER}`, borderRadius: 8, fontFamily: MONO, fontSize: 12 }}
                  formatter={(v) => brl(v)}
                />
              </PieChart>
            </ResponsiveContainer>
            <span style={{ fontFamily: MONO, fontSize: 11, color: TEXT_MUTED, letterSpacing: 1 }}>ALOCAÇÃO POR CATEGORIA</span>
          </div>
        </section>

        {/* Holdings list */}
        <section style={cardStyle}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: TEXT_MUTED, fontSize: 13 }}>
              <TrendingUp size={15} /> POSIÇÕES
            </div>
            <button onClick={() => setShowAdd(true)} style={btnGold}>
              <Plus size={14} /> Adicionar
            </button>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
            {holdings.map((h) => {
              const st = styleFor(h.category);
              return (
                <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: `1px solid ${BORDER}` }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: st.color + "22", color: st.color, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: MONO, fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                    {st.glyph}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14 }}>{h.name}</div>
                    <div style={{ fontSize: 11, color: TEXT_MUTED }}>{h.category}</div>
                  </div>
                  <div style={{ fontFamily: MONO, fontSize: 14 }}>{brl(h.value)}</div>
                  <button onClick={() => removeHolding(h.id)} style={iconBtn} aria-label="Remover">
                    <Trash2 size={14} />
                  </button>
                </div>
              );
            })}
            {holdings.length === 0 && (
              <div style={{ color: TEXT_MUTED, fontSize: 13, padding: "20px 0", textAlign: "center" }}>
                Nenhuma posição ainda. Adicione a primeira acima.
              </div>
            )}
          </div>
        </section>

        {/* Simulator */}
        <section style={{ ...cardStyle, marginTop: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, color: TEXT_MUTED, fontSize: 13, marginBottom: 14 }}>
            <Calculator size={15} /> SIMULADOR — PARA ONDE PODE IR
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14, marginBottom: 20 }} className="grid-stack-3">
            <Field label="Valor inicial">
              <input type="number" value={simInicial} onChange={(e) => setSimInicial(Number(e.target.value))} style={inputStyle} />
            </Field>
            <Field label="Aporte mensal">
              <input type="number" value={simAporte} onChange={(e) => setSimAporte(Number(e.target.value))} style={inputStyle} />
            </Field>
            <Field label="Prazo (anos)">
              <input type="number" value={simAnos} onChange={(e) => setSimAnos(Number(e.target.value))} style={inputStyle} />
            </Field>
          </div>

          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={simData} margin={{ left: -10, right: 10 }}>
              <CartesianGrid stroke={BORDER} strokeDasharray="3 3" />
              <XAxis dataKey="ano" tick={{ fill: TEXT_MUTED, fontFamily: MONO, fontSize: 11 }} label={{ value: "anos", position: "insideBottom", offset: -3, fill: TEXT_MUTED, fontSize: 11 }} />
              <YAxis tick={{ fill: TEXT_MUTED, fontFamily: MONO, fontSize: 11 }} tickFormatter={(v) => brl(v)} width={70} />
              <Tooltip contentStyle={{ background: PANEL_ALT, border: `1px solid ${BORDER}`, borderRadius: 8, fontFamily: MONO, fontSize: 12 }} formatter={(v) => brlFull(v)} />
              <Legend wrapperStyle={{ fontSize: 12, fontFamily: BODY }} />
              {scenarios.map((sc) => (
                <Line key={sc.label} type="monotone" dataKey={sc.label} stroke={sc.color} strokeWidth={2.2} dot={false} />
              ))}
            </LineChart>
          </ResponsiveContainer>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginTop: 16 }} className="grid-stack-3">
            {scenarios.map((sc) => {
              const last = simData[simData.length - 1];
              return (
                <div key={sc.label} style={{ background: PANEL_ALT, borderRadius: 10, padding: "12px 14px", border: `1px solid ${BORDER}` }}>
                  <div style={{ fontSize: 11, color: sc.color, fontFamily: MONO, letterSpacing: 1 }}>{sc.label.toUpperCase()} · {(sc.rate * 100).toFixed(0)}% a.a.</div>
                  <div style={{ fontFamily: DISPLAY, fontSize: 20, marginTop: 4 }}>{brl(last ? last[sc.label] : 0)}</div>
                </div>
              );
            })}
          </div>
          <p style={{ color: TEXT_MUTED, fontSize: 12, marginTop: 14, lineHeight: 1.5 }}>
            Projeção ilustrativa com juros compostos e rentabilidade constante — não é recomendação de investimento.
            Use para comparar cenários e decidir quanto aportar, não como promessa de retorno.
          </p>
        </section>
      </div>

      {/* Add holding modal */}
      {showAdd && (
        <div style={overlay} onClick={() => setShowAdd(false)}>
          <div style={modal} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <span style={{ fontFamily: DISPLAY, fontSize: 20 }}>Nova posição</span>
              <button onClick={() => setShowAdd(false)} style={iconBtn}><X size={16} /></button>
            </div>

            <Field label="Categoria">
              {!customCategory ? (
                <select
                  value={form.category}
                  onChange={(e) => {
                    if (e.target.value === "__custom__") { setCustomCategory(true); setForm({ ...form, category: "" }); }
                    else setForm({ ...form, category: e.target.value });
                  }}
                  style={inputStyle}
                >
                  {Object.keys(CATEGORY_STYLES).map((c) => <option key={c} value={c}>{c}</option>)}
                  <option value="__custom__">Outra…</option>
                </select>
              ) : (
                <input autoFocus placeholder="Nome da categoria" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} style={inputStyle} />
              )}
            </Field>
            <Field label="Nome do ativo">
              <input placeholder="ex: Tesouro IPCA+ 2029" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} style={inputStyle} />
            </Field>
            <Field label="Valor (R$)">
              <input type="number" placeholder="0" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} style={inputStyle} />
            </Field>

            <button onClick={addHolding} style={{ ...btnGold, width: "100%", justifyContent: "center", marginTop: 8, padding: "12px 0" }}>
              <Plus size={15} /> Adicionar à carteira
            </button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes ticker { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        @media (max-width: 720px) {
          .grid-stack { grid-template-columns: 1fr !important; }
          .grid-stack-3 { grid-template-columns: 1fr !important; }
        }
        input:focus, select:focus { outline: 2px solid ${GOLD}; outline-offset: 1px; }
        button:focus-visible { outline: 2px solid ${GOLD}; outline-offset: 2px; }
      `}</style>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label style={{ fontSize: 11, color: TEXT_MUTED, fontFamily: MONO, letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
        {label.toUpperCase()}
      </label>
      {children}
    </div>
  );
}

// ---------- design tokens ----------
const BG = "#0F1613";
const PANEL = "#151F1B";
const PANEL_ALT = "#1B2621";
const BORDER = "rgba(255,255,255,0.08)";
const TEXT = "#EDE8DE";
const TEXT_MUTED = "#8FA396";
const GOLD = "#C9A227";
const DISPLAY = "'Fraunces', serif";
const BODY = "'Inter', sans-serif";
const MONO = "'JetBrains Mono', monospace";

const FONT_IMPORTS = `@import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;700&display=swap');`;

const cardStyle = {
  background: PANEL,
  border: `1px solid ${BORDER}`,
  borderRadius: 14,
  padding: 20,
};
const btnGold = {
  display: "flex", alignItems: "center", gap: 6,
  background: GOLD, color: "#141A12", border: "none", borderRadius: 8,
  padding: "8px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer",
  fontFamily: BODY,
};
const iconBtn = {
  background: "transparent", border: "none", color: TEXT_MUTED, cursor: "pointer",
  padding: 6, borderRadius: 6, display: "flex", alignItems: "center",
};
const inputStyle = {
  width: "100%", background: PANEL_ALT, border: `1px solid ${BORDER}`, color: TEXT,
  borderRadius: 8, padding: "10px 12px", fontSize: 14, fontFamily: BODY, boxSizing: "border-box",
};
const overlay = {
  position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)",
  display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20,
};
const modal = {
  background: PANEL, border: `1px solid ${BORDER}`, borderRadius: 16, padding: 22,
  width: "100%", maxWidth: 380, display: "flex", flexDirection: "column", gap: 14,
};
